import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import "./DonatePage.css";

function DonatePage() {
  // State for dropdown open/close
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownVisible(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Sample student data (replace with API fetch later)
  const students = [
    {
      id: 1,
      name: "Help Aditi complete her studies",
      image: "https://images.indianexpress.com/2019/12/student-759-1.jpg",
      raised: 38000,
      goal: 50000,
      creator: "Ramesh Kumar",
    },
    {
      id: 2,
      name: "Support Raman's School Fund",
      image:
        "https://img.freepik.com/premium-photo/young-indian-boy-primary-school-wearing-his-school-uniform-smile-carries-his-backpack_1037914-132.jpg",
      raised: 61000,
      goal: 61000,
      creator: "Nazmin Bano",
    },
    {
      id: 3,
      name: "Help Ravi with Uniform & Books",
      image:
        "https://img.freepik.com/premium-photo/cute-indian-little-school-boy-uniform_601128-4671.jpg?w=2000",
      raised: 12000,
      goal: 25000,
      creator: "Neha Sharma",
    },
  ];

  // Open register page on donate button click
  function handleDonate() {
    // Later, you can redirect to the specific student's donate page
    window.location = "/register";
  }

  return (
    <div className="donate-page">
      {/* Navbar */}
      <header>
        <nav className="navbar">
          <div className="logo">
            <img
              src="https://as2.ftcdn.net/v2/jpg/01/99/05/35/1000_F_199053513_reNOz8CqNJx2zBhOUCTDpjcl3tb7CI.jpg"
              alt="EduRise Logo"
              style={{ height: "35px", verticalAlign: "middle" }}
            />
            <span style={{ fontWeight: "bold", fontSize: "20px", marginLeft: "10px", color: "#a60059" }}>
              EduRise
            </span>
          </div>
          <ul className="nav-links">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/donate" className="active">
                Donate
              </Link>
            </li>
            <li>
              <Link to="/pricing">Pricing</Link>
            </li>
            <li>
              <Link to="/code-of-practice">Code of Practice</Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
          </ul>
          <div className="login-dropdown" ref={dropdownRef}>
            <button onClick={() => setDropdownVisible(!dropdownVisible)}>
              Login ⯆
            </button>
            <div
              className="dropdown-content"
              style={{ display: dropdownVisible ? "block" : "none" }}
            >
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="donate-hero">
        <h2>Thousands are crowdfunding for various causes.</h2>
        <p>Support a fundraiser today.</p>
      </section>

      {/* Donation Cards */}
      <section className="donate-grid">
        {students.map((student) => (
          <div key={student.id} className="donate-card">
            <img src={student.image} alt={`Student ${student.id}`} />
            <div className="donate-content">
              <h4>{student.name}</h4>
              <p className="progress">
                Raised ₹{student.raised} / ₹{student.goal}
              </p>
              <p className="amount">Created by: {student.creator}</p>
              <button onClick={handleDonate}>Donate</button>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

export default DonatePage;
